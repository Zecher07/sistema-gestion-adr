
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, LogOut, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import OrderForm from '@/components/OrderForm';
import OrdersPanel from '@/components/OrdersPanel';
import Stats from '@/components/Stats';
import Login from '@/components/Login';
import Sidebar from '@/components/Sidebar';
import Notifications from '@/components/Notifications';
import OrderDetailsModal from '@/components/OrderDetailsModal';
import ClientForm from '@/components/ClientForm';
import ClientsPanel from '@/components/ClientsPanel';
import WorkAreaList from '@/components/WorkAreaList';
import WorkAreaCalendar from '@/components/WorkAreaCalendar';
import StatisticsCharts from '@/components/StatisticsCharts';
import DailyReport from '@/components/DailyReport';

// Proformas Components
import ProformasPanel from '@/components/ProformasPanel';
import ProformaForm from '@/components/ProformaForm';
import ProformaDetailsModal from '@/components/ProformaDetailsModal';

// Invoices Components
import InvoicesPanel from '@/components/InvoicesPanel';
import InvoiceForm from '@/components/InvoiceForm';
import InvoiceDetailsModal from '@/components/InvoiceDetailsModal';

// Workflows definitions for automatic advancement
const WORKFLOW_VPVC = ['VENTAS', 'PRODUCCION', 'VENTAS POR RETIRAR', 'CONTABILIDAD', 'FINALIZADA'];
const WORKFLOW_VC = ['VENTAS', 'CONTABILIDAD', 'FINALIZADA'];

function App() {
  const [user, setUser] = useState(null);
  
  // Data States
  const [orders, setOrders] = useState([]);
  const [clients, setClients] = useState([]); 
  const [proformas, setProformas] = useState([]);
  const [kanbanTasks, setKanbanTasks] = useState([]);
  const [invoices, setInvoices] = useState([]); // New Invoice State
  
  // UI States - Orders
  const [showForm, setShowForm] = useState(false);
  const [showAvailabilityModal, setShowAvailabilityModal] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null); 
  const [paymentOrder, setPaymentOrder] = useState(null);
  const [cloningOrder, setCloningOrder] = useState(null);
  const [viewOrder, setViewOrder] = useState(null);
  const [viewOrderSource, setViewOrderSource] = useState(null); // 'tasks' or null (general)

  // UI States - Proformas
  const [showProformaForm, setShowProformaForm] = useState(false);
  const [editingProforma, setEditingProforma] = useState(null);
  const [viewProforma, setViewProforma] = useState(null);

  // UI States - Invoices
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [initialInvoiceOrder, setInitialInvoiceOrder] = useState(null);
  const [viewInvoice, setViewInvoice] = useState(null);

  // UI States - General
  const [currentView, setCurrentView] = useState('inicio');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showClientFormModal, setShowClientFormModal] = useState(false);
  const [archivedNotifications, setArchivedNotifications] = useState([]);
  
  const [staffUsers, setStaffUsers] = useState([
    { id: '1', name: 'Administrador Principal', role: 'Administrador' },
    { id: '2', name: 'Juan Pérez (Vendedor)', role: 'Vendedor' },
    { id: '3', name: 'Ana Gomez (Vendedor)', role: 'Vendedor' },
    { id: '4', name: 'Carlos Producción', role: 'Producción' },
    { id: '5', name: 'Lucia Contabilidad', role: 'Contabilidad' }
  ]);

  const { toast } = useToast();

  // --- Persistence Helper ---
  const handlePersistence = (key, data) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      // Check for quota exceeded error
      const isQuotaExceeded = error instanceof DOMException && (
        error.code === 22 ||
        error.code === 1014 ||
        error.name === 'QuotaExceededError' ||
        error.name === 'NS_ERROR_DOM_QUOTA_REACHED'
      );

      if (isQuotaExceeded) {
        console.warn(`LocalStorage quota exceeded for ${key}. Initiating cleanup protocols.`);
        
        // Strategy 1: Clear non-essential data (Archived Notifications)
        if (key !== 'archivedNotifications') {
           localStorage.removeItem('archivedNotifications');
           // Retry saving
           try {
             localStorage.setItem(key, JSON.stringify(data));
             return; 
           } catch (retryError) {
             // Continue to next strategy
           }
        }

        // Strategy 2: Selective Storage / Compression for Orders
        if (key === 'productionOrders' && Array.isArray(data)) {
           // Filter out ARCHIVADA orders from persistence to save space
           const activeOrders = data.filter(o => o.status !== 'ARCHIVADA');
           
           if (activeOrders.length < data.length) {
              try {
                 localStorage.setItem(key, JSON.stringify(activeOrders));
                 toast({ 
                   title: "Almacenamiento Optimizado", 
                   description: "Se han excluido órdenes archivadas para liberar espacio.",
                   variant: "default"
                 });
                 return;
              } catch (e) { /* Continue */ }
           }

           // If still full, keep only the last 100 orders
           const recentOrders = data.slice(0, 100);
           try {
              localStorage.setItem(key, JSON.stringify(recentOrders));
              toast({ 
                title: "Almacenamiento Limitado", 
                description: "Espacio lleno. Solo se guardaron las 100 órdenes más recientes.",
                variant: "destructive"
              });
              return;
           } catch (e) { /* Continue */ }
        }

        // Strategy 3: Fallback to Session Storage
        try {
           sessionStorage.setItem(key, JSON.stringify(data));
           toast({ 
             title: "Modo Temporal (SessionStorage)", 
             description: "Almacenamiento local lleno. Datos guardados en sesión (se borrarán al cerrar el navegador).",
             variant: "destructive"
           });
        } catch (sessionError) {
           toast({ 
             title: "Error Crítico de Almacenamiento", 
             description: "No se pueden guardar los datos. Por favor contacte a soporte o use Supabase.",
             variant: "destructive"
           });
        }
      } else {
        console.error("LocalStorage Error:", error);
      }
    }
  };

  useEffect(() => {
    document.title = "Sistema de Órdenes de Producción";
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) setUser(JSON.parse(savedUser));
    
    try {
      const savedOrders = localStorage.getItem('productionOrders');
      const sysVersion = localStorage.getItem('sysVersion');
      if (sysVersion !== '1.0-reset') {
         setOrders([]); // Start empty
         localStorage.removeItem('productionOrders');
         localStorage.setItem('sysVersion', '1.0-reset');
         toast({ title: "Sistema Reiniciado", description: "Se han eliminado todas las órdenes anteriores." });
      } else {
         if (savedOrders) setOrders(JSON.parse(savedOrders));
      }

      const savedArchived = localStorage.getItem('archivedNotifications');
      if (savedArchived) setArchivedNotifications(JSON.parse(savedArchived));

      const savedClients = localStorage.getItem('clientsDB');
      if (savedClients) setClients(JSON.parse(savedClients));

      // Load Proformas
      const savedProformas = localStorage.getItem('proformasDB');
      if (savedProformas) setProformas(JSON.parse(savedProformas));

      // Load Kanban Tasks
      const savedKanban = localStorage.getItem('kanbanTasksDB');
      if (savedKanban) {
         setKanbanTasks(JSON.parse(savedKanban));
      } else {
         const dummyTasks = [
            { id: '1', title: 'Revisar pendientes de facturación', status: 'Pendiente', columnId: 'Lucia Contabilidad', description: 'Facturas de la semana pasada por revisar.', images: [] },
            { id: '2', title: 'Llamar a Cliente Importante', status: 'En proceso', columnId: 'Juan Pérez (Vendedor)', description: 'Confirmar medidas del letrero nuevo.', images: [] }
         ];
         setKanbanTasks(dummyTasks);
      }

      // Load Invoices
      const savedInvoices = localStorage.getItem('invoicesDB');
      if (savedInvoices) setInvoices(JSON.parse(savedInvoices));

    } catch (error) { console.error(error); }
  }, []);

  // --- Persistence Effects ---
  useEffect(() => {
    handlePersistence('productionOrders', orders);
  }, [orders]);
  
  useEffect(() => {
    if (clients.length > 0) handlePersistence('clientsDB', clients);
  }, [clients]);

  useEffect(() => {
    handlePersistence('archivedNotifications', archivedNotifications);
  }, [archivedNotifications]);

  useEffect(() => {
    handlePersistence('proformasDB', proformas);
  }, [proformas]);

  useEffect(() => {
    handlePersistence('kanbanTasksDB', kanbanTasks);
  }, [kanbanTasks]);

  useEffect(() => {
    handlePersistence('invoicesDB', invoices);
  }, [invoices]);


  const handleLogin = (userData) => {
    setUser(userData);
    handlePersistence('currentUser', userData);
    setStaffUsers(prev => {
       if (prev.find(u => u.name === userData.name)) return prev;
       return [...prev, { id: Date.now().toString(), name: userData.name, role: userData.role }];
    });
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  // --- Kanban Handlers ---
  const handleKanbanCreate = (taskData) => {
     const newTask = {
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        ...taskData
     };
     setKanbanTasks(prev => [...prev, newTask]);
     toast({ title: "Tarea creada", description: "Se ha añadido a la columna." });
  };

  const handleKanbanUpdate = (taskId, updates) => {
     setKanbanTasks(prev => prev.map(t => t.id === taskId ? { ...t, ...updates } : t));
     if (updates.status) {
        toast({ title: "Estado actualizado", description: `La tarea ahora está: ${updates.status}` });
     }
  };

  const handleKanbanDelete = (taskId) => {
     setKanbanTasks(prev => prev.filter(t => t.id !== taskId));
     toast({ title: "Tarea eliminada" });
  };

  // --- ID Helpers ---
  const getNextOrderNumber = () => {
    if (orders.length === 0) return 1;
    const maxNumber = orders.reduce((max, o) => {
       const num = parseInt(o.orderNumber || 0);
       return num > max ? num : max;
    }, 0);
    return maxNumber + 1;
  };
  
  const getNextProformaNumber = () => {
    if (proformas.length === 0) return 1;
    const maxNumber = proformas.reduce((max, p) => {
       const num = parseInt(p.proformaNumber || 0);
       return num > max ? num : max;
    }, 0);
    return maxNumber + 1;
  };

  const getNextInvoiceNumber = () => {
    if (invoices.length === 0) return 1;
    const maxNumber = invoices.reduce((max, inv) => {
       const num = parseInt(inv.sequential || 0);
       return num > max ? num : max;
    }, 0);
    return maxNumber + 1;
  };

  const formatOrderNumberForDisplay = (num) => {
    return num.toString().padStart(7, '0');
  };

  // --- Order Handlers ---
  const handleCreateOrder = (orderData) => {
    const orderNumber = orderData.orderNumber || getNextOrderNumber();
    const newOrder = {
      ...orderData,
      id: orderData.id || Date.now().toString(),
      orderNumber: orderNumber,
      status: 'VENTAS',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setOrders(prev => [newOrder, ...prev]);
    setShowForm(false);
    setCloningOrder(null);
    toast({ title: "✅ Orden creada", description: `Orden #${formatOrderNumberForDisplay(newOrder.orderNumber)} registrada` });
  };

  const handleUpdateOrder = (orderId, updatedData) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...updatedData, updatedAt: new Date().toISOString() } : o));
    setEditingOrder(null);
    setPaymentOrder(null);
    
    if (viewOrder && viewOrder.id === orderId) {
      setViewOrder(prev => ({ ...prev, ...updatedData, updatedAt: new Date().toISOString() }));
    }

    toast({ title: "💾 Actualizado", description: "Los cambios han sido guardados" });
  };

  const handleStatusChange = (orderId, newStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus, updatedAt: new Date().toISOString() } : o));
    let msg = `Nueva etapa: ${newStatus}`;
    if (newStatus === 'ANULADA') msg = "Orden anulada correctamente";
    if (newStatus === 'ARCHIVADA') msg = "Orden archivada exitosamente";
    if (newStatus === 'FINALIZADA' && orders.find(o=>o.id===orderId)?.status === 'ARCHIVADA') msg = "Orden restaurada de archivo";

    if (viewOrder && viewOrder.id === orderId) {
       setViewOrder(prev => ({ ...prev, status: newStatus }));
    }

    toast({ title: "Estado actualizado", description: msg });
  };

  const handleDeleteOrder = (orderId) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
    toast({ title: "🗑️ Eliminado", description: "Orden eliminada permanentemente del sistema" });
  };

  const handleCloneOrder = (order) => {
    const { id, createdAt, updatedAt, ...rest } = order;
    const clonedData = {
        ...rest,
        orderNumber: getNextOrderNumber(),
        status: 'VENTAS',
        fechaEntrega: '',
        anticipo: 0, 
        retencion: 0,
        financials: { ...rest.financials, saldo: rest.financials?.total || 0 },
        formaPagoAnticipo: 'No aplica',
        creditoVenceAnticipo: '',
        notaAnticipo: '',
        formaPagoSaldo: 'No aplica',
        creditoVenceSaldo: '',
        notaSaldo: '',
        factura: '',
        cotizacion: ''
    };
    setCloningOrder(clonedData);
  };

  // --- Proforma Handlers ---
  const handleCreateProforma = (proformaData) => {
    const newProforma = {
      ...proformaData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setProformas(prev => [newProforma, ...prev]);
    setShowProformaForm(false);
  };

  const handleUpdateProforma = (updatedData) => {
     setProformas(prev => prev.map(p => p.id === updatedData.id ? { ...p, ...updatedData, updatedAt: new Date().toISOString() } : p));
     setEditingProforma(null);
     if (viewProforma && viewProforma.id === updatedData.id) {
       setViewProforma({ ...viewProforma, ...updatedData });
     }
     toast({ title: "Proforma Actualizada", description: "Los cambios han sido guardados." });
  };

  const handleDeleteProforma = (proformaId) => {
    setProformas(prev => prev.filter(p => p.id !== proformaId));
    toast({ title: "Proforma Eliminada", description: "El registro ha sido borrado." });
  };

  const handleConvertProformaToOrder = (proforma) => {
    const mappedProducts = proforma.items.map(item => ({
      descripcion: item.producto,
      cantidad: item.cantidad,
      precio: item.precioUnitario,
      completed: false
    }));

    const newOrder = {
      id: Date.now().toString(),
      orderNumber: getNextOrderNumber(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'VENTAS',
      cliente: proforma.clienteData?.razonSocial || 'Cliente',
      clienteId: proforma.cliente,
      tipoLetrero: `PROFORMA #${proforma.proformaNumber}`,
      tipoOrden: 'VENTA CON PRODUCCION (VPVC) (4 pasos)',
      fechaEntrega: '', 
      productos: mappedProducts,
      financials: {
        subtotal: proforma.financials.subtotal,
        iva: proforma.financials.impuesto,
        total: proforma.financials.total,
        saldo: proforma.saldoMonto
      },
      anticipo: proforma.anticipoMonto,
      formaPagoAnticipo: proforma.formaPago,
      origenProformaId: proforma.proformaNumber,
      vendedor: proforma.responsable,
      notas: proforma.notasInternas,
      aplicarIva: proforma.financials.impuesto > 0,
      descuentoPorcentaje: 0
    };

    setOrders(prev => [newOrder, ...prev]);
    
    const updatedProforma = { 
       ...proforma, 
       status: 'APROBADA', 
       convertedToOrderId: newOrder.orderNumber 
    };
    handleUpdateProforma(updatedProforma);

    setViewProforma(null);
    toast({ 
      title: "✅ Conversión Exitosa", 
      description: `Se ha creado la Orden #${newOrder.orderNumber} y la proforma ha sido Aprobada.` 
    });
    setCurrentView('ordenes-todas');
  };

  // --- Invoice Handlers ---
  const handleCreateInvoice = (invoiceData) => {
     const newInvoice = {
       ...invoiceData,
       id: Date.now().toString(),
       createdAt: new Date().toISOString()
     };
     setInvoices(prev => [newInvoice, ...prev]);
     setShowInvoiceForm(false);
     setInitialInvoiceOrder(null);
     toast({ title: "Factura Emitida", description: `Se ha generado la factura #${newInvoice.sequential}.` });
  };

  const handleAnulateInvoice = (invoice) => {
    setInvoices(prev => prev.map(inv => inv.id === invoice.id ? { ...inv, status: 'ANULADA' } : inv));
    if (viewInvoice && viewInvoice.id === invoice.id) {
       setViewInvoice(prev => ({ ...prev, status: 'ANULADA' }));
    }
    toast({ title: "Factura Anulada", description: "El documento ha sido anulado." });
  };

  const handleGenerateInvoiceFromOrder = (order) => {
     setInitialInvoiceOrder(order);
     setViewOrder(null); // Close details modal
     setShowInvoiceForm(true);
  };

  // --- Client Handlers ---
  const handleCreateClient = (clientData) => {
    const newClient = {
      id: Date.now().toString(),
      ...clientData,
      createdAt: new Date().toISOString()
    };
    setClients(prev => [newClient, ...prev]);
    if (showClientFormModal) {
      setShowClientFormModal(false);
      toast({ title: "✅ Cliente registrado", description: "Ahora puede seleccionarlo en la orden." });
    } else {
      setCurrentView('clientes-lista');
      toast({ title: "✅ Cliente registrado", description: `${clientData.razonSocial} ha sido agregado exitosamente.` });
    }
  };

  // --- View Logic ---
  const handleProductToggle = (order, productIndex) => {
    if (user.role !== 'Producción') return;
    const updatedProducts = [...order.productos];
    updatedProducts[productIndex] = { ...updatedProducts[productIndex], completed: !updatedProducts[productIndex].completed };
    const updatedOrder = { ...order, productos: updatedProducts };
    setOrders(prev => prev.map(o => o.id === order.id ? updatedOrder : o));
    if (viewOrder && viewOrder.id === order.id) {
       setViewOrder(updatedOrder);
    }
  };

  const handleArchiveNotification = (orderId) => {
    setArchivedNotifications(prev => [...prev, orderId]);
    toast({ description: "Notificación archivada" });
  };

  const handleViewOrder = (order, source = null) => {
    setViewOrder(order);
    setViewOrderSource(source);
  };

  const handleViewChange = (viewId) => {
    if (viewId === 'ordenes-nueva') {
      setCurrentView('ordenes-todas');
      setShowForm(true);
    } else {
      setCurrentView(viewId);
    }
  };

  const getFilteredOrders = () => {
    switch (currentView) {
      case 'ordenes-todas':
        return orders;
      case 'ordenes-sin-factura':
        return orders.filter(o => !o.aplicarIva && o.status !== 'ARCHIVADA');
      case 'ordenes-con-factura':
        return orders.filter(o => o.aplicarIva && o.status !== 'ARCHIVADA');
      case 'ordenes-credito':
        return orders.filter(o => 
          (o.formaPagoAnticipo === 'Crédito' || 
          o.formaPagoSaldo === 'Crédito' || 
          o.status === 'CONTABILIDAD') && 
          o.status !== 'ARCHIVADA'
        );
      case 'ordenes-anuladas':
        return orders.filter(o => o.status === 'ANULADA');
      case 'ordenes-archivadas':
        return orders.filter(o => o.status === 'ARCHIVADA');
      default:
        if (currentView.startsWith('ordenes')) return orders.filter(o => o.status !== 'ARCHIVADA');
        return [];
    }
  };

  const handleAdvanceWorkflow = (order) => {
    if (!order) return;
    const isVC = order.tipoOrden && order.tipoOrden.includes('(VC)');
    const workflow = isVC ? WORKFLOW_VC : WORKFLOW_VPVC;
    const currentIndex = workflow.indexOf(order.status);
    if (currentIndex === -1 || currentIndex >= workflow.length - 1) {
       toast({ title: "No se puede avanzar", description: "La orden está en un estado final o desconocido.", variant: "destructive" });
       return;
    }
    const nextStatus = workflow[currentIndex + 1];
    handleStatusChange(order.id, nextStatus);
  };

  const handleArchiveOrder = (order) => {
    if (!order) return;
    handleStatusChange(order.id, 'ARCHIVADA');
    setViewOrder(null);
  };

  if (!user) return <><Login onLogin={handleLogin} /><Toaster /></>;

  const showDashboard = (user.role === 'Administrador' || user.role === 'Vendedor') && (currentView === 'inicio');

  const renderContent = () => {
    if (currentView === 'facturacion-panel') {
       return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <InvoicesPanel 
               invoices={invoices}
               onViewInvoice={setViewInvoice}
               onAnulateInvoice={handleAnulateInvoice}
             />
          </div>
       );
    }

    if (currentView === 'proformas') {
       return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <ProformasPanel 
                proformas={proformas}
                clients={clients}
                user={user}
                onCreateNew={() => setShowProformaForm(true)}
                onViewProforma={(p) => setViewProforma(p)}
                onEditProforma={(p) => setEditingProforma(p)}
                onDeleteProforma={handleDeleteProforma}
                onConvertToOrder={handleConvertProformaToOrder}
             />
          </div>
       );
    }

    if (currentView.startsWith('ordenes-')) {
       const filteredOrders = getFilteredOrders();
       return (
          <div className="space-y-6 animate-in fade-in duration-500">
            {showDashboard && <Stats orders={orders} />}
            <OrdersPanel
              orders={filteredOrders}
              user={user}
              onUpdateStatus={handleStatusChange}
              onDeleteOrder={handleDeleteOrder}
              onUpdateOrder={(id, data) => handleUpdateOrder(id, data)}
              onEditOrder={setEditingOrder}
              onCloneOrder={handleCloneOrder}
              onPaymentOrder={setPaymentOrder}
              onCreateOrder={() => setShowForm(true)}
              onViewOrder={(o) => handleViewOrder(o, null)} 
              currentView={currentView}
            />
          </div>
       );
    }

    switch (currentView) {
      case 'inicio':
        return (
           <div className="space-y-6 animate-in fade-in duration-500">
             <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-2xl font-bold text-slate-800 mb-2">¡Hola, {user.name}! 👋</h2>
                <p className="text-slate-500">Bienvenido al panel de control. Aquí tienes un resumen de la actividad reciente.</p>
             </div>
             <Stats orders={orders} />
             <div className="mt-8">
               <WorkAreaList 
                 orders={orders} 
                 user={user}
                 staffUsers={staffUsers}
                 kanbanTasks={kanbanTasks}
                 onKanbanUpdate={handleKanbanUpdate}
                 onKanbanCreate={handleKanbanCreate}
                 onKanbanDelete={handleKanbanDelete}
                 onViewOrder={(o) => handleViewOrder(o, 'tasks')}
                 initialMode='list'
               />
             </div>
           </div>
        );
      case 'clientes-lista':
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-4">
                <h2 className="text-xl font-bold text-slate-800">Gestión de Clientes</h2>
                <p className="text-slate-500 text-sm">Administra la base de datos de clientes.</p>
             </div>
             <ClientsPanel 
                clients={clients} 
                onCreateNew={() => setCurrentView('clientes-nuevo')}
             />
          </div>
        );
      case 'clientes-nuevo':
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <ClientForm 
                onSubmit={handleCreateClient}
                onCancel={() => setCurrentView('clientes-lista')}
             />
          </div>
        );
      case 'trabajo-listado':
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-4">
                <h2 className="text-xl font-bold text-slate-800">Área de Trabajo - Listado</h2>
                <p className="text-slate-500 text-sm">Visualiza tus tareas pendientes en formato de lista.</p>
             </div>
             <WorkAreaList 
                orders={orders} 
                user={user}
                staffUsers={staffUsers}
                kanbanTasks={kanbanTasks}
                onKanbanUpdate={handleKanbanUpdate}
                onKanbanCreate={handleKanbanCreate}
                onKanbanDelete={handleKanbanDelete}
                onViewOrder={(o) => handleViewOrder(o, 'tasks')}
                initialMode='list'
             />
          </div>
        );
      case 'trabajo-mistareas':
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-4">
                <h2 className="text-xl font-bold text-slate-800">Área de Trabajo - Tablero</h2>
                <p className="text-slate-500 text-sm">Gestiona visualmente las tareas en el tablero Kanban.</p>
             </div>
             <WorkAreaList 
                orders={orders} 
                user={user}
                staffUsers={staffUsers}
                kanbanTasks={kanbanTasks}
                onKanbanUpdate={handleKanbanUpdate}
                onKanbanCreate={handleKanbanCreate}
                onKanbanDelete={handleKanbanDelete}
                onViewOrder={(o) => handleViewOrder(o, 'tasks')}
                initialMode='board'
             />
          </div>
        );
      case 'trabajo-disponibilidad':
        return (
          <div className="space-y-6 animate-in fade-in duration-500 h-[calc(100vh-140px)]">
             <WorkAreaCalendar 
                orders={orders} 
                onViewOrder={(o) => handleViewOrder(o, 'tasks')}
             />
          </div>
        );
      case 'estadisticas-graficos':
        return <StatisticsCharts orders={orders} />;
      case 'estadisticas-reporte':
        return <DailyReport orders={orders} user={user} />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4 animate-in fade-in zoom-in duration-300">
             <div className="p-6 bg-slate-100 rounded-full">
                <Menu className="h-12 w-12 text-slate-400" />
             </div>
             <h2 className="text-xl font-bold text-slate-700">Sección en Construcción</h2>
             <p className="text-slate-500 max-w-md">
               La sección <span className="font-bold text-blue-600">{currentView ? currentView.charAt(0).toUpperCase() + currentView.slice(1) : ''}</span> está siendo desarrollada.
             </p>
             <Button onClick={() => setCurrentView('inicio')} variant="outline">
               Volver al Inicio
             </Button>
          </div>
        );
    }
  };

  return (
    <>
      <div className="min-h-screen bg-slate-50 print:bg-white flex">
        <div className="hidden md:block w-64 flex-shrink-0">
           <Sidebar 
             user={user} 
             onLogout={handleLogout} 
             currentView={currentView}
             onViewChange={handleViewChange}
           />
        </div>

        {/* Mobile Header */}
        <div className="md:hidden fixed top-0 left-0 right-0 z-30 bg-slate-900 text-white p-4 flex justify-between items-center shadow-md print:hidden">
           <span className="font-bold">Sistema Producción</span>
           <div className="flex items-center gap-3">
             <Notifications 
               user={user} 
               orders={orders} 
               archivedIds={archivedNotifications}
               onArchive={handleArchiveNotification}
               onViewOrder={(o) => handleViewOrder(o, 'tasks')}
             />
             <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
               <Menu className="h-6 w-6" />
             </button>
           </div>
        </div>

        {isMobileMenuOpen && (
           <div className="md:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setIsMobileMenuOpen(false)}>
              <div className="w-64 bg-slate-900 h-full shadow-2xl" onClick={e => e.stopPropagation()}>
                <Sidebar 
                  user={user} 
                  onLogout={handleLogout} 
                  currentView={currentView}
                  onViewChange={(view) => { handleViewChange(view); setIsMobileMenuOpen(false); }}
                />
              </div>
           </div>
        )}

        <div className="flex-1 w-full md:w-[calc(100%-16rem)] min-h-screen transition-all duration-300 flex flex-col">
           <div className="hidden md:flex bg-white border-b border-slate-200 h-16 px-8 items-center justify-end sticky top-0 z-20 shadow-sm print:hidden">
              <div className="flex items-center gap-4">
                 <Notifications 
                   user={user} 
                   orders={orders} 
                   archivedIds={archivedNotifications}
                   onArchive={handleArchiveNotification}
                   onViewOrder={(o) => handleViewOrder(o, 'tasks')}
                 />
                 <div className="h-8 w-[1px] bg-slate-200"></div>
                 <span className="text-sm font-semibold text-slate-700">{user.name}</span>
              </div>
           </div>

           <div className="container mx-auto px-4 py-8 md:p-8 mt-12 md:mt-0 flex-1 print:p-0 print:max-w-none print:mt-0">
              {renderContent()}
           </div>
        </div>
      </div>

      {/* --- Modals for Orders --- */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <OrderForm 
              currentUser={user} 
              clients={clients}
              staffUsers={staffUsers}
              onSubmit={handleCreateOrder} 
              onCancel={() => setShowForm(false)} 
              mode="create" 
              nextOrderNumber={getNextOrderNumber()}
              onCheckAvailability={() => setShowAvailabilityModal(true)}
              onCreateClient={() => setShowClientFormModal(true)}
            />
          </div>
        </div>
      )}

      {cloningOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setCloningOrder(null)}>
          <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <OrderForm 
              currentUser={user} 
              clients={clients}
              staffUsers={staffUsers}
              initialData={cloningOrder} 
              onSubmit={handleCreateOrder} 
              onCancel={() => setCloningOrder(null)} 
              mode="create"
              nextOrderNumber={getNextOrderNumber()}
              onCheckAvailability={() => setShowAvailabilityModal(true)}
              onCreateClient={() => setShowClientFormModal(true)}
            />
          </div>
        </div>
      )}

      {editingOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setEditingOrder(null)}>
          <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <OrderForm 
              currentUser={user} 
              clients={clients}
              staffUsers={staffUsers}
              initialData={editingOrder} 
              onSubmit={(data) => handleUpdateOrder(editingOrder.id, data)} 
              onCancel={() => setEditingOrder(null)} 
              mode="edit"
              onCheckAvailability={() => setShowAvailabilityModal(true)}
              onCreateClient={() => setShowClientFormModal(true)}
            />
          </div>
        </div>
      )}

      {paymentOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setPaymentOrder(null)}>
          <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <OrderForm 
              currentUser={user} 
              clients={clients}
              staffUsers={staffUsers}
              initialData={paymentOrder} 
              onSubmit={(data) => handleUpdateOrder(paymentOrder.id, data)} 
              onCancel={() => setPaymentOrder(null)} 
              mode="payment_only" 
            />
          </div>
        </div>
      )}

      {/* --- Modals for Proformas --- */}
      {showProformaForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setShowProformaForm(false)}>
           <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <ProformaForm 
                currentUser={user}
                clients={clients}
                staffUsers={staffUsers}
                onSubmit={handleCreateProforma}
                onCancel={() => setShowProformaForm(false)}
                mode="create"
                nextProformaNumber={getNextProformaNumber()}
              />
           </div>
        </div>
      )}

      {editingProforma && (
         <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 print:hidden" onClick={() => setEditingProforma(null)}>
           <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <ProformaForm 
                currentUser={user}
                clients={clients}
                staffUsers={staffUsers}
                initialData={editingProforma}
                onSubmit={handleUpdateProforma}
                onCancel={() => setEditingProforma(null)}
                mode="edit"
              />
           </div>
        </div>
      )}

      {viewProforma && (
         <ProformaDetailsModal 
           proforma={viewProforma}
           onClose={() => setViewProforma(null)}
           onEdit={(p) => { setViewProforma(null); setEditingProforma(p); }}
           onConvert={handleConvertProformaToOrder}
           onUpdateProforma={(updatedData) => handleUpdateProforma({ id: viewProforma.id, ...updatedData })}
           user={user}
           staffUsers={staffUsers}
         />
      )}

      {/* --- Modals for Invoices --- */}
      {showInvoiceForm && (
         <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4 print:hidden" onClick={() => setShowInvoiceForm(false)}>
            <div className="w-full max-w-5xl max-h-[95vh] overflow-y-auto h-full" onClick={e => e.stopPropagation()}>
               <InvoiceForm 
                 user={user}
                 initialOrder={initialInvoiceOrder}
                 nextInvoiceNumber={getNextInvoiceNumber()}
                 onSubmit={handleCreateInvoice}
                 onCancel={() => { setShowInvoiceForm(false); setInitialInvoiceOrder(null); }}
               />
            </div>
         </div>
      )}

      {viewInvoice && (
         <InvoiceDetailsModal 
            invoice={viewInvoice}
            onClose={() => setViewInvoice(null)}
            onAnulate={handleAnulateInvoice}
            onViewOrder={(orderId) => {
               // Optional: find order and view it
               const order = orders.find(o => o.id === orderId || o.orderNumber == orderId); // loose equality for orderNumber
               if(order) {
                  setViewInvoice(null);
                  handleViewOrder(order);
               }
            }}
         />
      )}


      {/* --- Helper Modals --- */}
      {showClientFormModal && (
         <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4">
            <div className="w-full max-w-md bg-white rounded-xl shadow-2xl p-6 relative">
               <button 
                 onClick={() => setShowClientFormModal(false)}
                 className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
               >
                 <X className="h-5 w-5" />
               </button>
               <h3 className="text-lg font-bold mb-4">Registrar Nuevo Cliente</h3>
               <ClientForm 
                  onSubmit={handleCreateClient}
                  onCancel={() => setShowClientFormModal(false)}
               />
            </div>
         </div>
      )}

      {showAvailabilityModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[70] p-4">
           <div className="w-full max-w-5xl bg-white h-[85vh] rounded-xl shadow-2xl flex flex-col">
              <div className="p-4 border-b flex justify-between items-center bg-slate-50 rounded-t-xl">
                 <h3 className="font-bold text-lg">Disponibilidad de Producción</h3>
                 <Button variant="ghost" size="icon" onClick={() => setShowAvailabilityModal(false)}>
                   <X className="h-5 w-5" />
                 </Button>
              </div>
              <div className="flex-1 overflow-hidden p-4">
                 <WorkAreaCalendar 
                    orders={orders} 
                    onViewOrder={(o) => { setShowAvailabilityModal(false); handleViewOrder(o, 'tasks'); }}
                 />
              </div>
           </div>
        </div>
      )}

      {/* Order Details Modal */}
      <OrderDetailsModal 
        order={viewOrder} 
        user={user} 
        staffUsers={staffUsers}
        onClose={() => setViewOrder(null)} 
        onProductToggle={handleProductToggle}
        isTaskView={viewOrderSource === 'tasks'}
        onAdvanceWorkflow={handleAdvanceWorkflow}
        onArchiveOrder={handleArchiveOrder}
        onUpdateOrder={handleUpdateOrder}
        onGenerateInvoice={handleGenerateInvoiceFromOrder}
      />

      <Toaster />
    </>
  );
}

export default App;
